import { MonitorUserRepository } from '@/server/repositories/monitor-user.repository';
import { toErrorMessage } from '@/server/utils/api-error';
import { hashPassword } from '@/server/utils/password';
import type {
	AssignMonitorUsersBodyInput,
	CreateMonitorUserBodyInput,
	MonitorUserListQueryInput,
	MonitorUserPlantsQueryInput,
	MonitorUserStatusCountsQueryInput,
	RelateMonitorUsersBodyInput,
} from '@/server/validators/monitor-user.validator';

interface ServiceError {
	status: 400 | 401 | 403 | 404 | 409 | 500;
	message: string;
}

interface LoginUserData {
	id: string;
	account: string;
	role: string;
	portal: string;
}

interface NumericMetric {
	value: number;
	unit: 'kW' | 'kWh';
}

interface RowStatus {
	normal: number;
	fault: number;
	standby: number;
	offline: number;
}

interface MonitorUserItem {
	id: string;
	account: string;
	affiliation: string;
	power: NumericMetric;
	today: NumericMetric;
	total: NumericMetric;
	status: RowStatus;
	matched: {
		serialNumber: string | null;
		installationDate: string | null;
	};
}

interface StatusCounts {
	all: number;
	normal: number;
	fault: number;
	standby: number;
	offline: number;
}

interface MonitorUserSummary {
	id: bigint;
	account: string;
	affiliation: string;
	power: number;
	today: number;
	total: number;
	status: RowStatus;
	matchedSerialNumber: string | null;
	matchedInstallationDate: string | null;
	updatedAt: Date;
}

interface ListSuccess {
	status: 200;
	message: string;
	data: {
		loginUser: LoginUserData;
		items: MonitorUserItem[];
		statusCounts: StatusCounts;
		pagination: {
			page: number;
			pageSize: number;
			totalItems: number;
			totalPages: number;
		};
		filters: {
			status: MonitorUserListQueryInput['status'];
			sortBy: MonitorUserListQueryInput['sortBy'];
			sortOrder: MonitorUserListQueryInput['sortOrder'];
			searchUser: string;
			searchSN: string;
			searchInstallationDate: string;
			searchAffiliation: string;
		};
	};
}

interface StatusCountsSuccess {
	status: 200;
	message: string;
	data: {
		loginUser: Pick<LoginUserData, 'id' | 'account' | 'role'>;
		statusCounts: StatusCounts;
		updatedAt: string;
	};
}

interface LiveSummarySuccess {
	status: 200;
	message: string;
	data: {
		items: Array<{
			id: string;
			power: NumericMetric;
			today: NumericMetric;
			total: NumericMetric;
			status: RowStatus;
			updatedAt: string;
		}>;
	};
}

interface PlantsSuccess {
	status: 200;
	message: string;
	data: {
		monitorUser: {
			id: string;
			account: string;
		};
		items: Array<{
			id: string;
			name: string;
			installationDate: string | null;
			deviceCount: number;
			status: RowStatus;
		}>;
		pagination: {
			page: number;
			pageSize: number;
			totalItems: number;
			totalPages: number;
		};
	};
}

interface BulkUpdateSuccess {
	status: 200;
	message: string;
	data: {
		assignedToUserId?: string;
		relatedUserId?: string;
		monitorUserIds: string[];
		assignedCount?: number;
		relatedCount?: number;
		updatedAt: string;
	};
}

interface CreateSuccess {
	status: 201;
	message: string;
	data: {
		id: string;
		account: string;
		email: string | null;
		phone: string | null;
		timezone: string | null;
		role: string;
		portal: string;
		status: string;
		createdAt: string;
	};
}

export type MonitorUserListResult = ListSuccess | ServiceError;
export type MonitorUserStatusCountsResult = StatusCountsSuccess | ServiceError;
export type MonitorUserLiveSummaryResult = LiveSummarySuccess | ServiceError;
export type MonitorUserPlantsResult = PlantsSuccess | ServiceError;
export type MonitorUserBulkUpdateResult = BulkUpdateSuccess | ServiceError;
export type MonitorUserCreateResult = CreateSuccess | ServiceError;

type ScopedMonitorUser = Awaited<
	ReturnType<MonitorUserRepository['findScopedMonitorUsers']>
>[number];

function normalizeDateOnly(date: Date | null): string | null {
	if (!date) {
		return null;
	}
	return date.toISOString().slice(0, 10);
}

function normalizeStatusLabel(status: string | null | undefined): string {
	if (!status) {
		return '';
	}
	return status.toLowerCase();
}

function computeRowStatus(entries: Array<{ online: boolean; status: string | null }>): RowStatus {
	const rowStatus: RowStatus = {
		normal: 0,
		fault: 0,
		standby: 0,
		offline: 0,
	};

	for (const entry of entries) {
		const statusLabel = normalizeStatusLabel(entry.status);

		if (statusLabel.includes('fault') || statusLabel.includes('abnormal')) {
			rowStatus.fault += 1;
			continue;
		}

		if (statusLabel.includes('standby')) {
			rowStatus.standby += 1;
			continue;
		}

		if (!entry.online || statusLabel.includes('offline')) {
			rowStatus.offline += 1;
			continue;
		}

		rowStatus.normal += 1;
	}

	return rowStatus;
}

function hasStatusMatch(statusFilter: MonitorUserListQueryInput['status'], status: RowStatus): boolean {
	if (statusFilter === 'all') {
		return true;
	}

	if (statusFilter === 'normal') {
		return status.normal > 0;
	}

	if (statusFilter === 'fault') {
		return status.fault > 0;
	}

	if (statusFilter === 'standby') {
		return status.standby > 0;
	}

	return status.offline > 0;
}

function toStatusCounts(items: MonitorUserSummary[]): StatusCounts {
	let normal = 0;
	let fault = 0;
	let standby = 0;
	let offline = 0;

	for (const item of items) {
		if (item.status.normal > 0) {
			normal += 1;
		}
		if (item.status.fault > 0) {
			fault += 1;
		}
		if (item.status.standby > 0) {
			standby += 1;
		}
		if (item.status.offline > 0) {
			offline += 1;
		}
	}

	return {
		all: items.length,
		normal,
		fault,
		standby,
		offline,
	};
}

function toRow(item: MonitorUserSummary): MonitorUserItem {
	return {
		id: String(item.id),
		account: item.account,
		affiliation: item.affiliation,
		power: {
			value: item.power,
			unit: 'kW',
		},
		today: {
			value: item.today,
			unit: 'kWh',
		},
		total: {
			value: item.total,
			unit: 'kWh',
		},
		status: item.status,
		matched: {
			serialNumber: item.matchedSerialNumber,
			installationDate: item.matchedInstallationDate,
		},
	};
}

export class MonitorUserService {
	constructor(
		private readonly monitorUserRepository: MonitorUserRepository = new MonitorUserRepository(),
	) { }

	private async getActor(actorId: bigint) {
		return this.monitorUserRepository.findActorById(actorId);
	}

	private async validateActor(actorId: bigint, actorRole: string | undefined): Promise<LoginUserData | ServiceError> {
		if (actorRole !== 'service_admin' && actorRole !== 'service_super_admin') {
			return {
				status: 403,
				message: 'You are not allowed to manage monitor users',
			};
		}

		const actor = await this.getActor(actorId);

		if (!actor || actor.isDeleted) {
			return {
				status: 401,
				message: 'Unauthorized',
			};
		}

		if (actor.portal !== 'service') {
			return {
				status: 403,
				message: 'You are not allowed to manage monitor users',
			};
		}

		return {
			id: String(actor.id),
			account: actor.account,
			role: actor.role,
			portal: actor.portal,
		};
	}

	private async fetchScopedMonitorUsers(actorId: bigint, actorRole?: string,) {
		return this.monitorUserRepository.findScopedMonitorUsers(actorId, actorRole);
	}

	private async buildSummaries(
		monitorUsers: ScopedMonitorUser[],
		filters: Pick<
			MonitorUserStatusCountsQueryInput,
			'searchUser' | 'searchSN' | 'searchInstallationDate' | 'searchAffiliation'
		>,
	): Promise<MonitorUserSummary[]> {
		if (monitorUsers.length === 0) {
			return [];
		}

		const accounts = monitorUsers.map((user) => user.account);
		const assignerIds = Array.from(
			new Set(
				monitorUsers
					.map((user) => user.assignedById)
					.filter((id): id is bigint => typeof id === 'bigint'),
			),
		);

		const [plants, assigners] = await Promise.all([
			this.monitorUserRepository.findPlantsByAccounts(accounts),
			this.monitorUserRepository.findAssignersByIds(assignerIds),
		]);

		const plantIds = plants.map((plant) => plant.id);
		const [inverters, dataloggers] = plantIds.length
			? await Promise.all([
				this.monitorUserRepository.findInvertersByPlantIds(plantIds),
				this.monitorUserRepository.findDataloggersByPlantIds(plantIds),
			])
			: [[], []];

		const affiliationById = new Map(assigners.map((item) => [String(item.id), item.account]));
		const plantsByAccount = new Map<string, typeof plants>();
		for (const plant of plants) {
			const current = plantsByAccount.get(plant.userAccount) ?? [];
			current.push(plant);
			plantsByAccount.set(plant.userAccount, current);
		}

		const devicesByPlant = new Map<string, Array<{ online: boolean; status: string | null; serialNumber: string }>>();
		// for (const item of inverters) {
		// 	const key = String(item.plantId);
		// 	const current = devicesByPlant.get(key) ?? [];
		// 	current.push({
		// 		online: item.online,
		// 		status: item.status,
		// 		serialNumber: item.serialNumber,
		// 	});
		// 	devicesByPlant.set(key, current);
		// }
		for (const item of dataloggers) {
			const key = String(item.plantId);
			const current = devicesByPlant.get(key) ?? [];
			current.push({
				online: item.online,
				status: item.status,
				serialNumber: item.serialNumber,
			});
			devicesByPlant.set(key, current);
		}

		const searchUser = filters.searchUser.trim().toLowerCase();
		const searchSN = filters.searchSN.trim().toLowerCase();
		const searchInstallationDate = filters.searchInstallationDate.trim();
		const searchAffiliation = filters.searchAffiliation.trim().toLowerCase();

		const summaries: MonitorUserSummary[] = [];
		for (const user of monitorUsers) {
			const affiliation =
				(typeof user.assignedById === 'bigint' && affiliationById.get(String(user.assignedById))) ||
				'';
			const userPlants = plantsByAccount.get(user.account) ?? [];

			let power = 0;
			let today = 0;
			let total = 0;
			let latestUpdatedAt = user.updatedAt;

			const deviceEntries: Array<{ online: boolean; status: string | null }> = [];
			let matchedSerialNumber: string | null = null;
			let matchedInstallationDate: string | null = null;
			let hasSNMatch = searchSN.length === 0;
			let hasDateMatch = searchInstallationDate.length === 0;

			for (const plant of userPlants) {
				// power += plant.powerValue;
				// today += plant.eTodayValue;
				// total += plant.eTotalValue;
				if (plant.updatedAt > latestUpdatedAt) {
					latestUpdatedAt = plant.updatedAt;
				}

				const installationDate = normalizeDateOnly(plant.installed);
				if (!hasDateMatch && installationDate && installationDate.includes(searchInstallationDate)) {
					hasDateMatch = true;
					matchedInstallationDate = installationDate;
				}

				const plantDevices = devicesByPlant.get(String(plant.id)) ?? [];
				for (const device of plantDevices) {
					deviceEntries.push({ online: device.online, status: device.status });
					if (
						!hasSNMatch &&
						device.serialNumber.toLowerCase().includes(searchSN)
					) {
						hasSNMatch = true;
						matchedSerialNumber = device.serialNumber;
					}
				}
			}

			const status = computeRowStatus(deviceEntries);

			if (
				searchUser.length > 0 &&
				!user.account.toLowerCase().includes(searchUser) &&
				!(user.email ?? '').toLowerCase().includes(searchUser) &&
				!(user.phone ?? '').toLowerCase().includes(searchUser)
				// !(user.mobile ?? '').toLowerCase().includes(searchUser)
			) {
				continue;
			}

			if (searchAffiliation.length > 0 && !affiliation.toLowerCase().includes(searchAffiliation)) {
				continue;
			}

			if (!hasSNMatch || !hasDateMatch) {
				continue;
			}

			summaries.push({
				id: user.id,
				account: user.account,
				affiliation,
				power,
				today,
				total,
				status,
				matchedSerialNumber,
				matchedInstallationDate,
				updatedAt: latestUpdatedAt,
			});
		}

		return summaries;
	}

	async getMonitorUserList(
		actorId: bigint,
		actorRole: string | undefined,
		query: MonitorUserListQueryInput,
	): Promise<MonitorUserListResult> {
		const actor = await this.validateActor(actorId, actorRole);
		if ('status' in actor) {
			return actor;
		}
		const loginUser: LoginUserData = actor;

		const monitorUsers = await this.fetchScopedMonitorUsers(actorId, actorRole);
		const summaries = await this.buildSummaries(monitorUsers, query);
		const statusCounts = toStatusCounts(summaries);

		const statusFiltered = summaries.filter((item) => hasStatusMatch(query.status, item.status));
		const sortOrderMultiplier = query.sortOrder === 'asc' ? 1 : -1;
		statusFiltered.sort((a, b) => {
			if (query.sortBy === 'power') {
				return (a.power - b.power) * sortOrderMultiplier;
			}
			if (query.sortBy === 'today') {
				return (a.today - b.today) * sortOrderMultiplier;
			}
			if (query.sortBy === 'total') {
				return (a.total - b.total) * sortOrderMultiplier;
			}

			return a.account.localeCompare(b.account) * sortOrderMultiplier;
		});

		const totalItems = statusFiltered.length;
		const totalPages = Math.max(1, Math.ceil(totalItems / query.pageSize));
		const safePage = Math.min(query.page, totalPages);
		const offset = (safePage - 1) * query.pageSize;
		const items = statusFiltered.slice(offset, offset + query.pageSize).map(toRow);

		return {
			status: 200,
			message: 'Monitor user list fetched successfully.',
			data: {
				loginUser,
				items,
				statusCounts,
				pagination: {
					page: safePage,
					pageSize: query.pageSize,
					totalItems,
					totalPages,
				},
				filters: {
					status: query.status,
					sortBy: query.sortBy,
					sortOrder: query.sortOrder,
					searchUser: query.searchUser,
					searchSN: query.searchSN,
					searchInstallationDate: query.searchInstallationDate,
					searchAffiliation: query.searchAffiliation,
				},
			},
		};
	}

	async getMonitorUserStatusCounts(
		actorId: bigint,
		actorRole: string | undefined,
		query: MonitorUserStatusCountsQueryInput,
	): Promise<MonitorUserStatusCountsResult> {
		const actor = await this.validateActor(actorId, actorRole);
		if ('status' in actor) {
			return actor;
		}
		const loginUser: LoginUserData = actor;

		const monitorUsers = await this.fetchScopedMonitorUsers(actorId);
		const summaries = await this.buildSummaries(monitorUsers, query);

		return {
			status: 200,
			message: 'Monitor user status counts fetched successfully.',
			data: {
				loginUser: {
					id: loginUser.id,
					account: loginUser.account,
					role: loginUser.role,
				},
				statusCounts: toStatusCounts(summaries),
				updatedAt: new Date().toISOString(),
			},
		};
	}

	async getMonitorUserLiveSummary(
		actorId: bigint,
		actorRole: string | undefined,
		monitorUserIds: bigint[],
	): Promise<MonitorUserLiveSummaryResult> {
		const actor = await this.validateActor(actorId, actorRole);
		if ('status' in actor && actor.status !== undefined) {
			return actor;
		}

		const scopedUsers = await this.monitorUserRepository.findScopedMonitorUsersByIds(
			actorId,
			actorRole,
			monitorUserIds
		);

		if (scopedUsers.length !== monitorUserIds.length) {
			return {
				status: 403,
				message: 'One or more monitor users are outside your scope',
			};
		}

		const summaries = await this.buildSummaries(scopedUsers, {
			searchUser: '',
			searchSN: '',
			searchInstallationDate: '',
			searchAffiliation: '',
		});

		return {
			status: 200,
			message: 'Live monitor user rows fetched successfully.',
			data: {
				items: summaries.map((item) => ({
					id: String(item.id),
					power: { value: item.power, unit: 'kW' },
					today: { value: item.today, unit: 'kWh' },
					total: { value: item.total, unit: 'kWh' },
					status: item.status,
					updatedAt: item.updatedAt.toISOString(),
				})),
			},
		};
	}

	async getMonitorUserPlants(
		actorId: bigint,
		actorRole: string | undefined,
		monitorUserId: bigint,
		query: MonitorUserPlantsQueryInput,
	): Promise<MonitorUserPlantsResult> {
		const actor = await this.validateActor(actorId, actorRole);
		if ('status' in actor && actor.status !== undefined) {
			return actor;
		}

		const monitorUser = await this.monitorUserRepository.findScopedMonitorUser(
			actorId,
			actorRole,
			monitorUserId,
		);

		if (!monitorUser) {
			return {
				status: 403,
				message: 'You are not allowed to access this monitor user',
			};
		}

		const [totalItems, plants] = await Promise.all([
			this.monitorUserRepository.countPlantsByUserAccount(monitorUser.account),
			this.monitorUserRepository.findPlantsByUserAccount(
				monitorUser.account,
				query.page,
				query.pageSize,
			),
		]);

		const plantIds = plants.map((plant) => plant.id);
		const [inverters, dataloggers] = plantIds.length
			? await Promise.all([
				this.monitorUserRepository.findInvertersByPlantIds(plantIds),
				this.monitorUserRepository.findDataloggersByPlantIds(plantIds),
			])
			: [[], []];

		const deviceEntriesByPlant = new Map<string, Array<{ online: boolean; status: string | null }>>();
		// for (const inverter of inverters) {
		// 	const key = String(inverter.plantId);
		// 	const current = deviceEntriesByPlant.get(key) ?? [];
		// 	current.push({ online: inverter.online, status: inverter.status });
		// 	deviceEntriesByPlant.set(key, current);
		// }
		for (const datalogger of dataloggers) {
			const key = String(datalogger.plantId);
			const current = deviceEntriesByPlant.get(key) ?? [];
			current.push({ online: datalogger.online, status: datalogger.status });
			deviceEntriesByPlant.set(key, current);
		}

		const totalPages = Math.max(1, Math.ceil(totalItems / query.pageSize));

		return {
			status: 200,
			message: 'Monitor user plant list fetched successfully.',
			data: {
				monitorUser: {
					id: String(monitorUser.id),
					account: monitorUser.account,
				},
				items: plants.map((plant) => {
					const deviceEntries = deviceEntriesByPlant.get(String(plant.id)) ?? [];
					return {
						id: String(plant.id),
						name: plant.name,
						installationDate: normalizeDateOnly(plant.installed),
						deviceCount: deviceEntries.length,
						status: computeRowStatus(deviceEntries),
					};
				}),
				pagination: {
					page: query.page,
					pageSize: query.pageSize,
					totalItems,
					totalPages,
				},
			},
		};
	}

	private async validateTargetServiceUser(targetUserId: bigint, actorId: bigint): Promise<ServiceError | null> {
		const target = await this.monitorUserRepository.findTargetServiceUser(targetUserId);

		if (!target) {
			return {
				status: 404,
				message: 'Target service user not found',
			};
		}

		if (target.id !== actorId && target.assignedById !== actorId) {
			return {
				status: 403,
				message: 'Target service user is outside your scope',
			};
		}

		return null;
	}

	private async updateMonitorUsersOwnership(
		monitorUserIds: bigint[],
		actorId: bigint,
		actorRole: string | undefined,
		targetUserId: bigint,
	) {
		const scopedUsers = await this.monitorUserRepository.findScopedMonitorUserIds(
			actorId,
			actorRole,
			monitorUserIds,
		);
		

		if (scopedUsers.length !== monitorUserIds.length) {
			return {
				error: {
					status: 403 as const,
					message: 'One or more monitor users are outside your scope',
				},
				updatedCount: 0,
			};
		}

		const updated = await this.monitorUserRepository.updateMonitorUsersAssignedBy(
			actorId,
			actorRole,
			monitorUserIds,
			targetUserId,
		);

		return {
			error: null,
			updatedCount: updated.count,
		};
	}

	async relateMonitorUsers(
		actorId: bigint,
		actorRole: string | undefined,
		input: RelateMonitorUsersBodyInput,
	): Promise<MonitorUserBulkUpdateResult> {
		const actor = await this.validateActor(actorId, actorRole);
		if ('status' in actor && actor.status !== undefined) {
			return actor;
		}

		const targetError = await this.validateTargetServiceUser(input.relatedUserId, actorId);
		if (targetError) {
			return targetError;
		}

		try {
			const updated = await this.updateMonitorUsersOwnership(
				input.monitorUserIds,
				actorId,
				actorRole,
				input.relatedUserId,
			);
			if (updated.error) {
				return updated.error;
			}

			return {
				status: 200,
				message: 'Monitor users related successfully.',
				data: {
					relatedUserId: String(input.relatedUserId),
					monitorUserIds: input.monitorUserIds.map((id) => String(id)),
					relatedCount: updated.updatedCount,
					updatedAt: new Date().toISOString(),
				},
			};
		} catch (error: unknown) {
			return {
				status: 500,
				message: toErrorMessage(error),
			};
		}
	}

	async assignMonitorUsers(
		actorId: bigint,
		actorRole: string | undefined,
		input: AssignMonitorUsersBodyInput,
	): Promise<MonitorUserBulkUpdateResult> {
		const actor = await this.validateActor(actorId, actorRole);
		if ('status' in actor && actor.status !== undefined) {
			return actor;
		}

		const targetError = await this.validateTargetServiceUser(input.assignedToUserId, actorId);
		if (targetError) {
			return targetError;
		}

		try {
			const updated = await this.updateMonitorUsersOwnership(
				input.monitorUserIds,
				actorId,
				actorRole,
				input.assignedToUserId,
			);
			if (updated.error) {
				return updated.error;
			}

			return {
				status: 200,
				message: 'Monitor users assigned successfully.',
				data: {
					assignedToUserId: String(input.assignedToUserId),
					monitorUserIds: input.monitorUserIds.map((id) => String(id)),
					assignedCount: updated.updatedCount,
					updatedAt: new Date().toISOString(),
				},
			};
		} catch (error: unknown) {
			return {
				status: 500,
				message: toErrorMessage(error),
			};
		}
	}

	async createMonitorUser(
		actorId: bigint,
		actorRole: string | undefined,
		input: CreateMonitorUserBodyInput,
	): Promise<MonitorUserCreateResult> {
		const actor = await this.validateActor(actorId, actorRole);
		if ('status' in actor && actor.status !== undefined) {
			return actor;
		}

		const existingAccount = await this.monitorUserRepository.findByAccountInsensitive(input.account);

		if (existingAccount) {
			return {
				status: 409,
				message: 'Account already exists',
			};
		}

		const existingEmail = await this.monitorUserRepository.findMonitoringUserByEmail(
			input.email,
		);

		if (existingEmail) {
			return {
				status: 409,
				message: 'Email already exists',
			};
		}

		try {
			const passwordHash = await hashPassword(input.password);
			const created = await this.monitorUserRepository.createMonitoringUser({
				account: input.account,
				email: input.email,
				phone: input.phone,
				timezone: input.timezone,
				passwordHash,
				assignedById: actorId,
			});

			return {
				status: 201,
				message: 'Monitor user created successfully.',
				data: {
					id: String(created.id),
					account: created.account,
					email: created.email,
					phone: created.phone,
					timezone: created.timezone,
					role: created.role,
					portal: created.portal,
					status: created.status,
					createdAt: created.createdAt.toISOString(),
				},
			};
		} catch (error: unknown) {
			return {
				status: 500,
				message: toErrorMessage(error),
			};
		}
	}
}
