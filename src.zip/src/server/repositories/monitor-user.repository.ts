import { prisma, type PrismaClient } from '@/server/db/prisma';

export class MonitorUserRepository {
	constructor(private readonly dbClient: PrismaClient = prisma) { }


	findActorById(actorId: bigint) {
		return this.dbClient.user.findUnique({
			where: { id: actorId },
			select: {
				id: true,
				account: true,
				role: true,
				portal: true,
				isDeleted: true,
			},
		});
	}

	findScopedMonitorUsers(
		actorId: bigint,
		actorRole?: string,
	) {
		return this.dbClient.user.findMany({
			where: {
				portal: 'monitoring',
				role: 'monitoring_user',
				status: 'active',
				isDeleted: false,

				...(actorRole === 'service_admin'
					? { assignedById: actorId }
					: {}),
			},

			select: {
				id: true,
				account: true,
				email: true,
				phone: true,
				timezone: true,
				assignedById: true,
				updatedAt: true,
			},
		});
	}
	// findScopedMonitorUsers(actorId: bigint) {
	// 	return this.dbClient.user.findMany({
	// 		where: {
	// 			portal: 'monitoring',
	// 			role: 'monitoring_user',
	// 			assignedById: actorId,
	// 			isDeleted: false,
	// 			status: 'active',
	// 		},
	// 		select: {
	// 			id: true,
	// 			account: true,
	// 			email: true,
	// 			phone: true,
	// 			// mobile: true,
	// 			timezone: true,
	// 			assignedById: true,
	// 			updatedAt: true,
	// 		},
	// 	});
	// }

	findScopedMonitorUsersByIds(
		actorId: bigint,
		actorRole: string | undefined,
		monitorUserIds: bigint[],
	) {
		return this.dbClient.user.findMany({
			where: {
				id: { in: monitorUserIds },
				portal: 'monitoring',
				role: 'monitoring_user',
				...(actorRole !== 'service_super_admin'
					? { assignedById: actorId }
					: {}),
				isDeleted: false,
				status: 'active',
			},
			select: {
				id: true,
				account: true,
				email: true,
				phone: true,
				// mobile: true,
				timezone: true,
				assignedById: true,
				updatedAt: true,
			},
		});
	}

	findScopedMonitorUser(
		actorId: bigint,
		actorRole: string | undefined,
		monitorUserId: bigint,
	) {
		return this.dbClient.user.findFirst({
			where: {
				id: monitorUserId,
				portal: 'monitoring',
				role: 'monitoring_user',
				...(actorRole !== 'service_super_admin'
					? { assignedById: actorId }
					: {}),
				isDeleted: false,
				status: 'active',
			},
			select: {
				id: true,
				account: true,
			},
		});
	}

	findPlantsByAccounts(accounts: string[]) {
		return this.dbClient.plant.findMany({
			where: {
				userAccount: {
					in: accounts,
				},
				deletedAt: null,
			},
			select: {
				id: true,
				userAccount: true,
				installed: true,
				// powerValue: true,
				// eTodayValue: true,
				// eTotalValue: true,
				updatedAt: true,
			},
		});
	}

	findAssignersByIds(assignerIds: bigint[]) {
		return this.dbClient.user.findMany({
			where: {
				id: {
					in: assignerIds,
				},
			},
			select: {
				id: true,
				account: true,
			},
		});
	}

	findInvertersByPlantIds(plantIds: bigint[]) {
		return this.dbClient.deviceInverter.findMany({
			where: {
				plantId: {
					in: plantIds,
				},
				deletedAt: null,
			},
			select: {
				plantId: true,
				// online: true,
				// status: true,
				serialNumber: true,
			},
		});
	}

	findDataloggersByPlantIds(plantIds: bigint[]) {
		return this.dbClient.deviceDatalogger.findMany({
			where: {
				plantId: {
					in: plantIds,
				},
				deletedAt: null,
			},
			select: {
				plantId: true,
				online: true,
				status: true,
				serialNumber: true,
			},
		});
	}

	countPlantsByUserAccount(userAccount: string) {
		return this.dbClient.plant.count({
			where: {
				userAccount,
				deletedAt: null,
			},
		});
	}

	findPlantsByUserAccount(userAccount: string, page: number, pageSize: number) {
		return this.dbClient.plant.findMany({
			where: {
				userAccount,
				deletedAt: null,
			},
			skip: (page - 1) * pageSize,
			take: pageSize,
			orderBy: {
				createdAt: 'desc',
			},
			select: {
				id: true,
				name: true,
				installed: true,
			},
		});
	}

	findTargetServiceUser(targetUserId: bigint) {
		return this.dbClient.user.findFirst({
			where: {
				id: targetUserId,
				portal: 'service',
				role: {
					in: ['service_admin', 'service_super_admin'],
				},
				isDeleted: false,
			},
			select: {
				id: true,
				assignedById: true,
			},
		});
	}

	findScopedMonitorUserIds(
		actorId: bigint,
		actorRole: string | undefined,
		monitorUserIds: bigint[],
	) {
		return this.dbClient.user.findMany({
			where: {
				id: {
					in: monitorUserIds,
				},
				portal: 'monitoring',
				role: 'monitoring_user',
				...(actorRole !== 'service_super_admin'
					? { assignedById: actorId }
					: {}),
				isDeleted: false,
				status: 'active',
			},
			select: {
				id: true,
			},
		});
	}

	updateMonitorUsersAssignedBy(
		actorId: bigint,
		actorRole: string | undefined,
		monitorUserIds: bigint[],
		targetUserId: bigint,
	) {
		return this.dbClient.user.updateMany({
			where: {
				id: {
					in: monitorUserIds,
				},
				portal: 'monitoring',
				role: 'monitoring_user',
				...(actorRole !== 'service_super_admin'
					? { assignedById: actorId }
					: {}),
				isDeleted: false,
				status: 'active',
			},
			data: {
				assignedById: targetUserId,
			},
		});
	}

	findByAccountInsensitive(account: string) {
		return this.dbClient.user.findFirst({
			where: {
				account: {
					equals: account,
					mode: 'insensitive',
				},
			},
			select: { id: true },
		});
	}

	findMonitoringUserByEmail(email: string) {
		return this.dbClient.user.findFirst({
			where: {
				portal: 'monitoring',
				email: {
					equals: email,
					mode: 'insensitive',
				},
				isDeleted: false,
			},
			select: { id: true },
		});
	}

	createMonitoringUser(input: {
		account: string;
		email: string;
		phone: string;
		timezone: string;
		passwordHash: string;
		assignedById: bigint;
	}) {
		return this.dbClient.user.create({
			data: {
				account: input.account,
				email: input.email,
				phone: input.phone,
				// mobile: input.phone.slice(0, 10),
				timezone: input.timezone,
				passwordHash: input.passwordHash,
				portal: 'monitoring',
				role: 'monitoring_user',
				status: 'active',
				assignedById: input.assignedById,
			},
			select: {
				id: true,
				account: true,
				email: true,
				phone: true,
				timezone: true,
				role: true,
				portal: true,
				status: true,
				createdAt: true,
			},
		});
	}
}
